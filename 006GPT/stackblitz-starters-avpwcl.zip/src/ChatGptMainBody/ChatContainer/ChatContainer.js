import React from 'react';
// import styles from "./ChatContainer.module.css";

function ChatContainer(props) {
  return <>ChatContainer from ChatContainer</>;
}

export default ChatContainer;
